# todo_list

A Todo list for a object-oriented subject for a college project, written in Java.


## Contributors

- [Adam](https://github.com/AJai3) - Main Developer
- [Gustavo](https://github.com/) - Maind Developer 2 and Co-Author
