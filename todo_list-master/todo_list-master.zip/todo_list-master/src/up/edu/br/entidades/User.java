//classe representado um único 'todo'

package up.edu.br.entidades;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class User {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private int id;
    private String nome;
    private String description;
    private boolean status;

    public User() {}

    public User(int id, String nome, String description, boolean completed) {
        this.id = id;
        this.nome = nome;
        this.description = description;
        this.status = completed;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() { return nome; }

    public void setNome(String user) { this.nome = user; }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean completed) {
        this.status = completed;
    }

    @Override
    public String toString() {
        return "[" + id + "] " + description + " (Completed: " + status + ")";
    }
}
