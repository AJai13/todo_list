package up.edu.br.front;

public class Principal {
	public static void main(String[] args) {
		int opc;
		do{
			System.out.println("\n\n");
			System.out.println("*** MENU PRINCIPAL ***");
			System.out.println("1 - Usuario           ");
			System.out.println("2 - Tarefas   		  ");
			System.out.println("3 - Sair			  ");
			opc = Console.readInt("Opção: ");
			switch(opc){
				case 1:
					new UserApp();
					break;
				case 2:
					new TodoApp();
					break;
			}
		}while(opc != 3);
	}
}
