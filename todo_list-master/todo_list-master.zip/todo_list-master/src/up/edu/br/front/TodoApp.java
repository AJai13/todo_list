package up.edu.br.front;

import up.edu.br.entidades.ToDo;
import up.edu.br.persistencia.TodoList;

import java.util.List;

public class TodoApp {
    public TodoApp(){
        int opc;

        do{
            System.out.println("\n\n*** LISTA DE TAREFAS ***");
            System.out.println("1 - Criar lista             ");
            System.out.println("2 - Adicionar tarefa        ");
            System.out.println("3 - Remover tarefa          ");
            System.out.println("4 - Modificar tarefa        ");
            System.out.println("5 - Listar listas           ");
            System.out.println("6 - Excluir lista           ");
            System.out.println("7 - Voltar                  ");
            System.out.println("============================");
            opc = Console.readInt("Opção:           ");

            switch(opc){
                case 1:
                    criarLista();
                    break;
                case 2:
                    //adicionar();
                    break;
                case 3:
                    //remover();
                    break;
                case 4:
                    //modificar();
                    break;
                case 5:
                    //listarListas();
                    break;
                case 6:
                    //excluirLista();
                    break;
            }
        }while(opc != 7);
    }
    public static void criarLista(){
        System.out.println("******** CRIAÇÃO DA LISTA *********");
        ToDo objLista = new ToDo();
        objLista.setTitulo(Console.readString("Digite o titulo da lista:"));
        if (TodoList.procurarPorTitulo(objLista) == null){
            TodoList.incluir(objLista);
            System.out.println("Inlusão bem sucedida. ");
        } else {
            System.out.println("Usuário já cadastrado.");
        }
    }
}
